# TicTacToe Dance (Native Android App)

Нативное Android-приложение на Kotlin (не HTML):
- Игра «Крестики-нолики» с ботом (лёгкий / средний / непобедимый).
- При любом исходе (победа, ничья, поражение) запускается нативный анимированный танцующий человечек (`DanceView` на Android `Canvas`).
- При проигрыше боту после танца срабатывает `Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)` — приложение реально сворачивается и перекидывает обратно на рабочий стол системы Android.

## Как собрать APK

### Вариант 1: Через GitHub Actions (прямо с телефона)
1. Загрузите содержимое архива в репозиторий на GitHub.
2. Откройте вкладку **Actions** → **Build Debug APK** → **Run workflow**.
3. Скачайте готовый `app-debug.apk` из Artifacts и установите на телефон.

### Вариант 2: В Android Studio (на ПК)
1. Откройте папку `tictactoe-dance-android` в Android Studio.
2. Дождитесь синхронизации Gradle и нажмите **Run** или **Build > Build APK(s)**.
