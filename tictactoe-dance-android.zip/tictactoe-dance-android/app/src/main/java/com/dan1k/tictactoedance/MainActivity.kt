package com.dan1k.tictactoedance

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.FrameLayout
import android.widget.GridLayout
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import kotlin.random.Random

class MainActivity : AppCompatActivity() {

    private val board = Array<String?>(9) { null }
    private val cells = mutableListOf<Button>()
    private var gameOver = false
    private val handler = Handler(Looper.getMainLooper())

    private lateinit var statusText: TextView
    private lateinit var danceOverlay: LinearLayout
    private lateinit var danceTitle: TextView
    private lateinit var danceView: DanceView
    private lateinit var playAgainBtn: Button

    private val winCombos = arrayOf(
        intArrayOf(0, 1, 2), intArrayOf(3, 4, 5), intArrayOf(6, 7, 8),
        intArrayOf(0, 3, 6), intArrayOf(1, 4, 7), intArrayOf(2, 5, 8),
        intArrayOf(0, 4, 8), intArrayOf(2, 4, 6)
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = FrameLayout(this).apply {
            setBackgroundColor(Color.parseColor("#0B0F19"))
        }

        val gameLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(48, 64, 48, 64)
        }

        val titleText = TextView(this).apply {
            text = "Крестики-нолики"
            textSize = 26f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }
        gameLayout.addView(titleText)

        statusText = TextView(this).apply {
            text = "Ваш ход (X)"
            textSize = 16f
            setTextColor(Color.parseColor("#38BDF8"))
            gravity = Gravity.CENTER
            setPadding(0, 24, 0, 36)
        }
        gameLayout.addView(statusText)

        val grid = GridLayout(this).apply {
            rowCount = 3
            columnCount = 3
        }

        val cellSize = (resources.displayMetrics.widthPixels * 0.26).toInt()
        for (i in 0 until 9) {
            val btn = Button(this).apply {
                textSize = 32f
                setTextColor(Color.WHITE)
                setBackgroundColor(Color.parseColor("#1E293B"))
                val params = GridLayout.LayoutParams().apply {
                    width = cellSize
                    height = cellSize
                    setMargins(10, 10, 10, 10)
                }
                layoutParams = params
                setOnClickListener { onCellClick(i) }
            }
            cells.add(btn)
            grid.addView(btn)
        }
        gameLayout.addView(grid)

        val resetBtn = Button(this).apply {
            text = "Новая игра"
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.parseColor("#0284C7"))
            setPadding(32, 24, 32, 24)
            setOnClickListener { resetGame() }
        }
        val resetParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = 40 }
        gameLayout.addView(resetBtn, resetParams)

        root.addView(gameLayout)

        danceOverlay = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(Color.parseColor("#F0050814"))
            setPadding(48, 48, 48, 48)
            visibility = View.GONE
        }

        danceTitle = TextView(this).apply {
            textSize = 22f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, 24)
        }
        danceOverlay.addView(danceTitle)

        danceView = DanceView(this)
        val danceParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            (resources.displayMetrics.heightPixels * 0.42).toInt()
        )
        danceOverlay.addView(danceView, danceParams)

        playAgainBtn = Button(this).apply {
            text = "Играть снова"
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.parseColor("#0284C7"))
            setOnClickListener { resetGame() }
        }
        val againParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = 32 }
        danceOverlay.addView(playAgainBtn, againParams)

        root.addView(danceOverlay)
        setContentView(root)
    }

    private fun onCellClick(index: Int) {
        if (gameOver || board[index] != null) return
        board[index] = "X"
        cells[index].text = "X"
        cells[index].setTextColor(Color.parseColor("#38BDF8"))

        val res = checkWinner()
        if (res != null) {
            finishGame(res)
            return
        }

        statusText.text = "Ход бота..."
        handler.postDelayed({ botMove() }, 320)
    }

    private fun botMove() {
        if (gameOver) return
        val empty = board.indices.filter { board[it] == null }
        if (empty.isEmpty()) return

        val move = empty[Random.nextInt(empty.size)]
        board[move] = "O"
        cells[move].text = "O"
        cells[move].setTextColor(Color.parseColor("#FB7185"))

        val res = checkWinner()
        if (res != null) {
            finishGame(res)
        } else {
            statusText.text = "Ваш ход (X)"
        }
    }

    private fun checkWinner(): String? {
        for (combo in winCombos) {
            val a = board[combo[0]]
            if (a != null && a == board[combo[1]] && a == board[combo[2]]) {
                return a
            }
        }
        return if (board.all { it != null }) "DRAW" else null
    }

    private fun finishGame(winner: String) {
        gameOver = true
        danceOverlay.visibility = View.VISIBLE
        danceView.resetAnimation()

        when (winner) {
            "X" -> {
                danceView.accentColor = Color.parseColor("#38BDF8")
                danceTitle.text = "Победа! Танцующий человечек с тобой!"
                playAgainBtn.visibility = View.VISIBLE
            }
            "DRAW" -> {
                danceView.accentColor = Color.parseColor("#FBBF24")
                danceTitle.text = "Ничья! Человечек всё равно танцует!"
                playAgainBtn.visibility = View.VISIBLE
            }
            else -> {
                danceView.accentColor = Color.parseColor("#FB7185")
                danceTitle.text = "Поражение! Возврат в систему через 4 сек..."
                playAgainBtn.visibility = View.GONE
                handler.postDelayed({
                    val homeIntent = Intent(Intent.ACTION_MAIN).apply {
                        addCategory(Intent.CATEGORY_HOME)
                        flags = Intent.FLAG_ACTIVITY_NEW_TASK
                    }
                    startActivity(homeIntent)
                    resetGame()
                }, 4000)
            }
        }
    }

    private fun resetGame() {
        handler.removeCallbacksAndMessages(null)
        gameOver = false
        for (i in 0 until 9) {
            board[i] = null
            cells[i].text = ""
        }
        statusText.text = "Ваш ход (X)"
        danceOverlay.visibility = View.GONE
    }
}
