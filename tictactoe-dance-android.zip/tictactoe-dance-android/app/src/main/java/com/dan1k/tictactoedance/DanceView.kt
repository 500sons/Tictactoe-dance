package com.dan1k.tictactoedance

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.util.AttributeSet
import android.view.View
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

class DanceView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#0B0F19")
    }
    private val limbPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#38BDF8")
        strokeCap = Paint.Cap.ROUND
        style = Paint.Style.STROKE
    }
    private val headFillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        style = Paint.Style.FILL
    }
    private val facePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#0F172A")
        style = Paint.Style.FILL
    }
    private val floorPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#1E293B")
        style = Paint.Style.FILL
    }

    private var startTimeMs = System.currentTimeMillis()
    var accentColor: Int = Color.parseColor("#38BDF8")
        set(value) {
            field = value
            limbPaint.color = value
        }

    fun resetAnimation() {
        startTimeMs = System.currentTimeMillis()
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return

        canvas.drawRect(0f, 0f, w, h, bgPaint)

        val t = (System.currentTimeMillis() - startTimeMs) / 1000f
        val beat = t * 7.5f
        val scale = min(w, h) / 300f

        val bounce = abs(sin(beat)) * h * 0.05f
        val sway = sin(beat * 0.5f) * w * 0.04f
        val cx = w / 2f + sway
        val hipY = h * 0.60f - bounce
        val shoulderY = hipY - h * 0.18f
        val headY = shoulderY - h * 0.09f

        canvas.drawOval(
            w * 0.28f, h * 0.80f,
            w * 0.72f, h * 0.87f,
            floorPaint
        )

        limbPaint.strokeWidth = 8f * scale

        // Тело
        canvas.drawLine(cx, shoulderY, cx - sway * 0.2f, hipY, limbPaint)

        // Голова
        val headRadius = 20f * scale
        canvas.drawCircle(cx, headY, headRadius, headFillPaint)
        canvas.drawCircle(cx, headY, headRadius, limbPaint)

        // Глаза
        canvas.drawCircle(cx - 6f * scale, headY - 3f * scale, 2.5f * scale, facePaint)
        canvas.drawCircle(cx + 6f * scale, headY - 3f * scale, 2.5f * scale, facePaint)

        // Руки
        val leftArmAngle = sin(beat) * 0.9f - 0.6f
        val rightArmAngle = cos(beat) * 0.9f + 0.6f

        val lElbowX = cx - cos(leftArmAngle) * 34f * scale
        val lElbowY = shoulderY + sin(leftArmAngle) * 28f * scale
        val lHandX = lElbowX - sin(beat * 1.2f) * 24f * scale
        val lHandY = lElbowY - 26f * scale
        canvas.drawLine(cx, shoulderY + 4f * scale, lElbowX, lElbowY, limbPaint)
        canvas.drawLine(lElbowX, lElbowY, lHandX, lHandY, limbPaint)

        val rElbowX = cx + cos(rightArmAngle) * 34f * scale
        val rElbowY = shoulderY - sin(rightArmAngle) * 28f * scale
        val rHandX = rElbowX + cos(beat * 1.2f) * 24f * scale
        val rHandY = rElbowY - 26f * scale
        canvas.drawLine(cx, shoulderY + 4f * scale, rElbowX, rElbowY, limbPaint)
        canvas.drawLine(rElbowX, rElbowY, rHandX, rHandY, limbPaint)

        // Ноги
        val kickL = maxOf(0f, sin(beat)) * 28f * scale
        val kickR = maxOf(0f, -sin(beat)) * 28f * scale

        val lKneeX = cx - 22f * scale - kickL * 0.4f
        val lKneeY = hipY + 34f * scale - kickL * 0.3f
        val lFootX = cx - 28f * scale - kickL * 0.8f
        val lFootY = h * 0.83f - kickL
        canvas.drawLine(cx - sway * 0.2f, hipY, lKneeX, lKneeY, limbPaint)
        canvas.drawLine(lKneeX, lKneeY, lFootX, lFootY, limbPaint)

        val rKneeX = cx + 22f * scale + kickR * 0.4f
        val rKneeY = hipY + 34f * scale - kickR * 0.3f
        val rFootX = cx + 28f * scale + kickR * 0.8f
        val rFootY = h * 0.83f - kickR
        canvas.drawLine(cx - sway * 0.2f, hipY, rKneeX, rKneeY, limbPaint)
        canvas.drawLine(rKneeX, rKneeY, rFootX, rFootY, limbPaint)

        postInvalidateOnAnimation()
    }
}
